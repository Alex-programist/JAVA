package com.company;
import java.util.Scanner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.io.*;

public class Task3 {
    public static void extractLetters() {

          String filename = "C:\\Users\\38066\\IdeaProjects\\untitled16\\demo111.txt";
          String str;
          //FileWriter fw = new FileWriter(filename);
        //  fw.write(str);
    }
}