package com.company;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.io.*;


public class Task4
{
    public static void main(String args[]) throws IOException {
        Path fileName = Path.of("C:\\Users\\38066\\IdeaProjects\\untitled16\\demo.txt");
        String st = Files.readString(fileName);
        //Scanner sc=new Scanner(System.in);
        //String st;
        //System.out.println("Ведіть речення");
        //st=sc.nextLine();
        //String w[]=st.split(""); //розбтваємо рядок на окремі символи
        //int count=0,j=0;
        String words[]=st.split(" "); // розбити весь рядок на окремі слова
        System.out.println("Вивід слів з парною кількостю симовлів:");
        //char symbol = words.length
        for(int i=0;i<words.length;i++) {
            // if(w[i].equals("")||w[i].equals(" "))  //буде істинним, коли слово закінчується
            //{

            if (words.length % 2 == 0)  //перевіряємо, чи слово закінчене містить парний номер. слів чи ні
            {
                st = words[i];
                System.out.println(words[i]); // якщо містить, то надрукуйте це слово
                //String filename = "";
                //FileWriter fw = new FileWriter(filename);
                //fw.write(words[i] + '\n');
                //fw.close();
                // String actual = Files.readString(fileName1);
                //System.out.println(actual);
            }
        }
        }
    }

